import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>
          Welcome to Full Stack Development - 1
        </h1>
        <h2>
          React JS Programming Week09 Lab Exercise
        </h2>
        <h3>
          101422064
        </h3>
        <h4>
          Edwin Chung
        </h4>
        <p>
          George Brown College, Toronto
        </p>
      </header>
    </div>
  );
}

export default App;
